from flask import Flask #flask 불러오기
from flask import render_template
app = Flask(__name__)

@app.route('/')
def index():
 return render_template('index.html') #index.html 템플릿 연동


if __name__ == '__main__': #서버실행
   app.debug=True
   app.run()